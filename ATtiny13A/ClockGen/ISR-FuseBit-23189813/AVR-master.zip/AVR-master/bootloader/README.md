Writing your own Bootloader
==========================


## Why?

An exercise in understanding what goes into writing a bootloader and why is it required. Deeper understanding of the intricacies of a RISC controller.

## How?

A lot will be borrowed from existing bootloaders (obviously) but that will only be done later. Right now, simply creation of our simple bootloader is the objective.
