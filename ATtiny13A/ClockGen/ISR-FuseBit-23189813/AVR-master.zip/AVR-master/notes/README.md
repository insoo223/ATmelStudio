Development notes and log
=========================

## Why?

I would love to keep all of my experiments together with the code and it seems like a good idea to keep them all in one place.



## Contents

 1. [Controllers 101](Controllers101.md)
 2. [Controller Internals](Internals.md)