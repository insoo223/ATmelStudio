/***********************************************************************
 *
 *  avra - Assembler for the Atmel AVR microcontroller series
 *
 *  Copyright (C) 1998-2003 Jon Anders Haugum, Tobias Weber
 *
 * Misc stuff
 */

enum boolean {False = 0, True};

enum filetype
{
    AVRSTUDIO = 0,
    GENERIC,
    INTEL,
    MOTOROLA
};

